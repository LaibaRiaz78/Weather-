let weather = {
  apiKey: "bb1274016c99e3675e6ec4e754032970",
  lat: 37.7749,
  lon: -122.4194,
  fetchWeather: function (city) {
    fetch(
      "https://api.openweathermap.org/data/2.5/weather?q=" +
      city +
      "&units=metric&appid=" +
      this.apiKey

    )
      .then((response) => {
        if (!response.ok) {
          alert("No weather found.");
          throw new Error("No weather found.");
        }
        return response.json();
      })
      .then((data) => this.displayWeather(data));

    // fetch 7 day forecast
    fetch(
      "https://api.openweathermap.org/data/2.5/forecast?q=" +
      city +
      "&units=metric&appid=" +
      this.apiKey

    )
      .then((response) => {
        if (!response.ok) {
          alert("No forecast found.");
          throw new Error("No forecast found.");
        }
        return response.json();
      })
      .then((data) => this.displayForecast(data));
  },
  displayWeather: function (data) {
    const { name } = data;

    const { icon, description } = data.weather[0];
    const { temp, humidity } = data.main;
    const { speed } = data.wind;

    document.querySelector(".city").innerText = "Weather in " + name;
    document.querySelector(".icon").src =
      "https://openweathermap.org/img/wn/" + icon + ".png";
    document.querySelector(".description").innerText = description;
    document.querySelector(".temp").innerText = temp + "°C";
    document.querySelector(".humidity").innerText =
      "Humidity: " + humidity + "%";
    document.querySelector(".wind").innerText =
      "Wind speed: " + speed + " km/h";
    document.querySelector(".weather").classList.remove("loading");
    document.body.style.backgroundImage =
      "url('https://source.unsplash.com/1600x900/?" + name + "')";
  },
  displayForecast: function (data) {
    const forecastContainer = document.querySelector(".forecast");
    forecastContainer.innerHTML = "";

    data.list.forEach((day, index) => {

      if (index % 8 === 0) { // display every 8th item (every 24 hours)
        const date = new Date(day.dt * 1000);

        const dayOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"][date.getDay()];
        const temp = day.main.temp;
        const description = day.weather[0].description;
        const icon = day.weather[0].icon;

        const forecastHTML = `
         <div class="weeks">
         <div class="forecast-day">
            <h2>${dayOfWeek}</h2>
            <p>Temperature: ${temp}°C</p>
            <p>Description: ${description}</p>
             
          </div>
         </div>

        `;

        forecastContainer.innerHTML += forecastHTML;
      }
    });
  },
  search: function () {
    this.fetchWeather(document.querySelector(".search-bar").value);
  },
};

document.querySelector(".search button").addEventListener("click", function () {
  weather.search();
});

document
  .querySelector(".search-bar")
  .addEventListener("keyup", function (event) {
    if (event.key == "Enter") {
      weather.search();
    }
  });

weather.fetchWeather("RahimYar Khan");

function update() {
  const date = new Date();
  const hours = (date.getHours() % 12).toString().padStart(2, 0);
  const minutes = date.getMinutes().toString().padStart(2, 0);
  const seconds = date.getSeconds().toString().padStart(2, 0);
  const meridiem = date.getHours() >= 12 ? "PM" : "AM";
  const time = hours + ":" + minutes + ":" + seconds + " " + meridiem;
  const main = document.getElementById("clock");
  main.textContent = time;
}

update();
setInterval(update, 1000);


